package app10;

public class EntryPoint
{

	public static void main(String[] args)
	{
		new AdvancedGrades();
	}

}
