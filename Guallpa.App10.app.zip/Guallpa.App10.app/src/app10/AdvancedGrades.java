package app10;

import javax.swing.JOptionPane;

public class AdvancedGrades
{

	public AdvancedGrades()
	{
		int classSize;
		int[][] studentGrades;
		String[] studentGradesOutput;
		String[] studentNames; 
		int[] studentAvgGrades;
		
		classSize = classSizeIdentifier();
		classSizeDisplay(classSize);
		
		classSizeValue(classSize);
		
		studentNames = studentNamesAssigner(classSize);
		
		studentGrades = classGradesAssigner(classSize, studentNames);
		
		studentGradesOutput = studentGradesOutputString(studentGrades, classSize);
		
		studentAvgGrades = classAverageGrades(studentGrades, classSize);
		
		for (int count1 = 0; count1 < classSize; count1++)
		{
			displayStudentInformation(studentGradesOutput, studentAvgGrades, studentNames, count1);
		}
		
	}
	public int classSizeIdentifier()
	{
		int classSize;
		
		classSize = Integer.parseInt(JOptionPane.showInputDialog("Enter the the size of the class you would like to grade for"));
				
		return classSize;
	}
	
	public void classSizeDisplay(int classSize)
	{
		JOptionPane.showMessageDialog(null, "The size of the class you are grading for is " + classSize + ".");
	}
	
	public void classSizeIsLargeDisplay(int classSize)
	{
		JOptionPane.showMessageDialog(null, "The class of" + classSize + " is too large, please enter the size of the class again. ");
		
		classSizeIdentifier();
	}
	
	public void classSizeIsSmallDisplay(int classSize)
	{
		JOptionPane.showMessageDialog(null, "The class of" + classSize + " is too small, please enter the size of the class again. ");
		
		classSizeIdentifier();
	}
	
	public void classSizeValue(int classSize)
	{
		if (classSize > 20 || classSize < 5)
		{
			classSizeIsLargeDisplay(classSize);
		}
		else if (classSize < 5)
		{
			classSizeIsSmallDisplay(classSize);
		}
	}
	
	public String studentNames(int classSize, int count)
	{
		String studentName;
		
		studentName = JOptionPane.showInputDialog("Enter the full name of student # " + (count + 1) + " in this class of " + classSize + " Students");
		
		return studentName;
	}
	
	public int studentGrades(String[] StudentNames, int count1, int count2)
	{
		int studentGrade;
		
		studentGrade = Integer.parseInt(JOptionPane.showInputDialog("Please grade #" + (count2 + 1) + " for " + StudentNames[count1] + "." ));
		
		return studentGrade;
	}
	
	public char numericGradeToLetterGrade(int studentGrade)
	{
		if (studentGrade >= 90)
		{
			return 'A';
		}
		else if (studentGrade >= 80)
		{
			return 'B';
		}
		else if (studentGrade >= 70)
		{
			return 'C';
		}
		else if (studentGrade >= 60)
		{
			return 'D';
		}
		else
		{
			return 'F';
		}
		
	}
	
	public String[] studentNamesAssigner(int classSize)
	{
		String[] studentNames = new String[classSize];
		
		for (int count1 = 0; count1 < studentNames.length; count1++)
		{
			studentNames[count1] = studentNames(classSize, count1);
		}
		
		return studentNames;
	}
	
	public int[][] classGradesAssigner(int classSize, String studentNames[])
	{
		int[][] studentGrades = new int[classSize][12];
		
		for (int count1 = 0; count1 < studentNames.length; count1++)
		{
			for (int count2 = 0; count2 < 12; count2++) 
			{
				studentGrades[count1][count2] = studentGrades(studentNames, count1, count2);
			}
			
		}
		
		return studentGrades;
	}
	
	public int[] classAverageGrades(int[][] studentGrades, int classSize)
	{
		int[] studentAvgGrades = new int[classSize];
		
		for (int count1 = 0; count1 < studentAvgGrades.length; count1++)
		{
			for (int count2 = 0; count2 < 12; count2++)
			{
				studentAvgGrades[count1] += studentGrades[count1][count2];
			}
			
			studentAvgGrades[count1] = (studentAvgGrades[count1] / 12);
		}
		
		return studentAvgGrades;
	}
	
	public String[] studentGradesOutputString(int[][] studentGrades, int classSize)
	{
		String[] studentGradesOutput = new String[classSize];
		
		for (int count1 = 0; count1 < studentGradesOutput.length; count1++)
		{
			studentGradesOutput[count1] = "";
			for (int count2 = 0; count2 < 12; count2++)
			{
				studentGradesOutput[count1] += studentGrades[count1][count2] + ", ";
			}
		}
		
		return studentGradesOutput;
	}
	
	public void displayStudentInformation(String[] studentGradesOutput, int[] studentAvgGrades, String[] studentNames, int count1)
	{
		String message = studentNames[count1] + "'s grades are: " + studentGradesOutput[count1] + " their average exam score is: " + studentAvgGrades[count1] + " their average grade as a letter grade is: " + numericGradeToLetterGrade(studentAvgGrades[count1]);
		
		JOptionPane.showMessageDialog(null, message);
	}
	

}
